# HYDRA role packet

Six roles from the SCBE swarm: KO Scout, AV Vision, RU Reader, CA Clicker, UM Typer, DR Judge.

This zip is the packet builder. It does not include a browser agent and it is not a license for the MIT repository. The repository stays free at https://github.com/issdandavis/SCBE-AETHERMOORE

```
python hydra_packet.py self-test
python hydra_packet.py "Check that the shop download matches its manual."
```

The printed JSON leaves `decision` empty. Fill ALLOW, QUARANTINE, or DENY yourself, then check that record with the governance toolkit if you have it.
