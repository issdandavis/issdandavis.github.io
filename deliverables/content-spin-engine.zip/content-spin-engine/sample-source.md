The shop lists six downloads.
Each download has a self-test.
Books stay on Amazon.
