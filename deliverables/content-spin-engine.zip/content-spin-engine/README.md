# Content Spin Engine

`spin.py` copies one source note into a site draft, a short draft, and an email draft. It does not add a claim.

```
python spin.py self-test
python spin.py sample-source.md https://aethermoore.com/shop.html
```

Drafts land in `spin-out/` next to the source, with `output-tracker.csv`.
