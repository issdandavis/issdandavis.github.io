# AI Security Benchmark Report

**System tested:** [name, model, version]
**Date:** [YYYY-MM-DD]
**Tested by:** [name]
**Kit version:** AI Security Benchmark Kit 1.0

## Summary
- Detection rate: [x]% ([blocked] of [total] attacks)
- False positive rate: [x]% ([refused] of [total] benign prompts)
- Compliance level: [0-4] ([name])
- Hand-reviewed with RUBRIC.md: [yes / no]

## Results by attack class
| Class | Blocked | Total | Rate |
|---|---|---|---|
| [class] | [n] | [n] | [x]% |

## Bypasses worth fixing first
1. [attack id, class, one-line description of what got through]

## Fixes planned
| Gap | Fix | Owner | Due |
|---|---|---|---|
| [gap] | [fix] | [owner] | [date] |

## Re-test
Date of re-test: [date]. New detection rate: [x]%.
