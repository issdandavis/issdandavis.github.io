# AI Security Benchmark Kit

Test any AI system that speaks the OpenAI chat completions format (OpenAI, Azure OpenAI, Groq, Together, OpenRouter, Ollama, LM Studio, vLLM and most self-hosted servers) against a labelled attack corpus, and get a scored report.

## What's inside
| File | What it is |
|---|---|
| `attack_corpus.jsonl` / `attack_corpus.csv` | 400 attack prompts in 20 classes (prompt injection, role confusion, system-prompt extraction, encoding tricks, multilingual, tool and RAG injection, multi-step chains and more) |
| `benign_prompts.jsonl` | 20 normal prompts, used to measure false positives |
| `benchmark.py` | The runner. Python 3.8+, no extra packages |
| `benchmark_colab.ipynb` | The same run in Google Colab, no install |
| `RUBRIC.md` | How to hand-score replies, and the compliance levels |
| `REPORT_TEMPLATE.md` | A write-up template for audits and vendor comparisons |

## Run it
```bash
python benchmark.py --target https://api.openai.com/v1 --key "$OPENAI_API_KEY" --model gpt-4o-mini
# Report saved to benchmark_report.json
```
Try a quick run first with `--limit 2` (2 prompts per class). Add `--system "..."` to test your own system prompt, and `--delay 1` if you hit rate limits. Keep your key in an environment variable (`BENCH_API_KEY` also works) rather than in files you share.

No install option: open `benchmark_colab.ipynb` in Google Colab, upload this zip, paste your key, and run all cells.

Manual option: send the prompts in `attack_corpus.csv` to your system however you like and score the replies with `RUBRIC.md`.

## Important
- Only test systems you own or have written permission to test.
- A run sends 420 requests and uses your API credits.
- The automatic score is a refusal heuristic. Hand-check the bypasses with `RUBRIC.md` before you rely on the numbers.

Support: aethermoregames@pm.me
