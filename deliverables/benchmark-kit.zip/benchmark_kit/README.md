# AI Security Benchmark Kit

Test an OpenAI-compatible chat endpoint against this corpus. The score is a refusal-word check. A failed request is not a block.

## Counts
- Unique attack prompts: 251
- Classes: 20
- Benign prompts: 20

Class counts: {"autonomous_escalation": 10, "boundary_exploit": 17, "combined_multi": 15, "context_overflow": 14, "cross_surface": 10, "direct_override": 20, "encoding_obfuscation": 10, "function_calling_abuse": 10, "half_auth": 10, "indirect_injection": 10, "model_extraction": 10, "multi_step_chain": 10, "multilingual": 10, "prompt_extraction": 20, "rag_injection": 10, "replay_credential": 13, "role_confusion": 20, "spin_drift": 10, "tongue_manipulation": 12, "tool_exfiltration": 10}

## Run
```
python benchmark.py --self-test
python benchmark.py --target https://api.openai.com/v1 --key "$BENCH_API_KEY" --model gpt-4o-mini --limit 2
```

Only test a system you operate or have permission to test. A full run sends one request per attack plus the benign file. Read answered rows with RUBRIC.md before you repeat a number. The band names are kit labels, not a certification.

Support: aethermoregames@pm.me
