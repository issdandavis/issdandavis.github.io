# Validation

- Import SCBE_Decision_Check.workflow.json
- Confirm the workflow is inactive until you choose to turn it on
- POST one QUARANTINE record and receive HTTP 200
- POST `{"decision":"MAYBE"}` and receive HTTP 400
