# n8n Workflow Pack

Import `workflows/SCBE_Decision_Check.workflow.json`.

The webhook path is `scbe-decision`. The code node accepts a JSON body whose `decision` is ALLOW, QUARANTINE, or DENY and whose `rationale` is non-empty. A good record gets HTTP 200. Anything else gets HTTP 400.

No API key is required. Activate the workflow, then:

```
curl -s -X POST "$WEBHOOK_URL" -H "content-type: application/json" -d "{\"decision\":\"QUARANTINE\",\"rationale\":\"The file has not been opened.\",\"workflow\":\"shop\",\"owner\":\"buyer\"}"
```

Replace WEBHOOK_URL with the URL n8n shows for this node. The workflow ships inactive.
