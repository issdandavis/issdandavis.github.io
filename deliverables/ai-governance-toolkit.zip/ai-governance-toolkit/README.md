# AI Governance Toolkit

`decide.py` checks one decision record. The decision word is ALLOW, QUARANTINE, or DENY. QUARANTINE and DENY also need uncertainty and a follow-up.

```
python decide.py self-test
python decide.py example allow > allow.json
python decide.py check allow.json
```

The examples in this folder already pass. Edit a copy for a real workflow.
