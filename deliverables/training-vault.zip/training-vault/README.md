# AI Security Training Vault

This vault is a starter, not the public corpus.

- `governance_starter.jsonl` has 24 prompt/response rows about the decision words, the six roles, and these packs.
- `validate_sft.py` checks that every row has a non-empty prompt and response.

```
python validate_sft.py self-test
python validate_sft.py governance_starter.jsonl
```

The large SCBE training set is public and MIT licensed at https://huggingface.co/datasets/issdandavis/scbe-aethermoore-training-data
This zip does not contain that set.
